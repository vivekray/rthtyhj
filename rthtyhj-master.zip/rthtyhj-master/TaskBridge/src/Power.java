
public class Power {

}
