
public class LinkedListStack {

}
