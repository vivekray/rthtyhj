
public interface Genrics<E> {
	void push(E v);
		E pop();
	    E peek();

}
